package TICTAC;


	
	public class UnavailableCellException extends Exception {

		public UnavailableCellException() {
			// TODO Auto-generated constructor stub
		}

		public UnavailableCellException(String arg0) {
			super(arg0);
			// TODO Auto-generated constructor stub
		}


}
